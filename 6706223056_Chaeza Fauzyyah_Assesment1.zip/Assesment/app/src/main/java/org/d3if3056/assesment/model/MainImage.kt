package org.d3if3056.assesment.model

import androidx.annotation.DrawableRes

data class MainImage(
    val nama: String,
    @DrawableRes val imageResId: Int
)
